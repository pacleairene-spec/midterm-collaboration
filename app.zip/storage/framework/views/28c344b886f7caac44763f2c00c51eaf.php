

<?php $__env->startSection('content'); ?>
<h2>Edit Item</h2>
<form action="<?php echo e(route('items.update', $item)); ?>" method="POST">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <div class="mb-3">
        <label>Name</label>
        <input type="text" name="name" value="<?php echo e($item->name); ?>" class="form-control">
    </div>
    <div class="mb-3">
        <label>Quantity</label>
        <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>" class="form-control">
    </div>
    <div class="mb-3">
        <label>Price</label>
        <input type="text" name="price" value="<?php echo e($item->price); ?>" class="form-control">
    </div>
    <div class="mb-3">
        <label>Category</label>
        <select name="category_id" class="form-control">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php echo e($item->category_id == $category->id ? 'selected' : ''); ?>>
                    <?php echo e($category->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <button class="btn btn-primary">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\inventory-system\resources\views/items/edit.blade.php ENDPATH**/ ?>