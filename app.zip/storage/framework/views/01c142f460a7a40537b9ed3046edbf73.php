

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Items</h2>
        <a href="<?php echo e(route('items.create')); ?>" class="btn btn-success">Add Item</a>
    </div>

    <table class="table table-bordered text-center align-middle">
        <thead class="table-dark">
            <tr>
                <th style="width: 8%">ID</th>
                <th style="width: 20%">Name</th>
                <th style="width: 12%">Quantity</th>
                <th style="width: 15%">Price</th>
                <th style="width: 25%">Category</th>
                <th style="width: 20%"> </th> 
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->quantity); ?></td>
                <td>₱<?php echo e(number_format($item->price, 2)); ?></td>
                <td><?php echo e($item->category->name); ?></td>
                <td>
                    <a href="<?php echo e(route('items.edit', $item->id)); ?>" class="btn btn-sm btn-warning me-2">Edit</a>
                    <form action="<?php echo e(route('items.destroy', $item->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete this item?')">
                            Delete
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\inventory-system\resources\views/items/index.blade.php ENDPATH**/ ?>