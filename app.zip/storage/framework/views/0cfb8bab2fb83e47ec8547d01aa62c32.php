

<?php $__env->startSection('content'); ?>
<h2>Edit Category</h2>
<form action="<?php echo e(route('categories.update', $category)); ?>" method="POST">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <div class="mb-3">
        <label>Name</label>
        <input type="text" name="name" value="<?php echo e($category->name); ?>" class="form-control">
    </div>
    <button class="btn btn-primary">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\inventory-system\resources\views/categories/edit.blade.php ENDPATH**/ ?>